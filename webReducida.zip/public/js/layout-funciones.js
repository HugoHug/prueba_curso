/*
 * Arreglos jQuery
 * Optimización, 3 de febrero.
 * 1. Generar un nuevo PopOver con más opciones.
 * 
 */


// Hacer que cambie la flecha de los botones que colapsan el contenido, esto aplica para los links hechos con bootstrap.

	function animarFlecha( dataId , btnClass ){
		
		var btnClass = '.' + btnClass;
		var dataId = '#' + dataId;

	  $( dataId ).on("hide.bs.collapse", function(){
	    $( btnClass ).html('abrir <i class="fa fa-angle-down"></i>');
	  });
	  $( dataId ).on("show.bs.collapse", function(){
	    $( btnClass ).html('cerrar <i class="fa fa-angle-up"></i>');
	  });

	 }

	animarFlecha('indicadores','colapsar');				
		

// Habilitar TABS (arreglo por item)		

	function ejecutarTabs( listId ) {
		// el tab se ejecuta con el ID de la lista de navegación
		// var listId = listId;
		$( listId + ' .nav-tabs > li > a,'+listId + ' .nav-pills > li > a' ).click(function (e) {
			e.preventDefault();
			$(this).tab('show');
		});												  				
	}

	// Llama el modulo de datos complementarios
	ejecutarTabs('#tenenciaTabs');
	

// MODULO EXTENDIDO, Ocultar mostrar información y extender módulo

	function ocultarMostrar( divId ) {
		// como los modulos deben mostrar un item, lo harán siempre y cuando tengan el mismo nombre
		var divId = divId;
		
		$( '.'+ divId ).click(function(e) {
			e.preventDefault();
		  				  														
		// Amplia y reduce las columnas
		  $( '#moduloDatosCliente' ).toggleClass( 'col-md-6 col-md-12').toggleClass( 'col-lg-4 col-lg-8 overDash');
		  $( '#generales' ).toggleClass('col-md-12 col-md-6');

		// Oculta y muestra el modulo complementario
		  $( '#'+ divId ).fadeToggle( 'slow' ).toggleClass('col-md-12 hidden col-md-6');
		  				
		});				
		
				
	}

	// Llama el modulo de datos complementarios
	ocultarMostrar('complementarios');		


		
	// ACORDEON (COLLAPSE Sencillo), por item heredado y consecutivo.

	function colapsarDatoIndividual( btnHerencia ){
		
		$( btnHerencia ).next('div').addClass( "collpase in" );

		$( btnHerencia ).click(function(e) {
			e.preventDefault();	  
			$( this ).next('div').collapse('toggle');
			
		});	
	}
	
	colapsarDatoIndividual( '#grupoGenerales > a' );
	colapsarDatoIndividual( '#grupoComplementarios > a' );
	
	
	//v2  ACORDEON (COLLAPSE), en caso de tener muchos modulos y querer cerrar cada uno

	function colapsarSeccionIndividual( btnAccionDiv ){
		
		//$( btnAccionDiv ).next('div').addClass( "collpase in" );

		$( btnAccionDiv ).click(function(e) {
			e.preventDefault();	  
			$( this ).next('div').collapse('toggle');
		});	
	}
	
	colapsarSeccionIndividual( '.collapse-next' );


	// ACORDEON (COLLAPSE VARIOS), multiples objetos que se colapsan: esto solo muestra los elementos al mismo tiempo; o los oculta.
	
	function collapsarDatos( btngrupoId ) {
	
		var btnClass = '.' + btngrupoId;
		var grupoId = '#' + btngrupoId;
		
	    var active = true;
	
	    $( btnClass ).click(function () {
	        if (active) {
	            active = false;
	            $( grupoId + ' > div').collapse('show');
	            //$('.panel-title').attr('data-toggle', '');
	            $(this).html('<i class="fa fa-angle-down"></i>');
	        } else {
	            active = true;
	            $( grupoId + ' > div').collapse('hide');
	            //$('.panel-title').attr('data-toggle', 'collapse');
	            $(this).html('<i class="fa fa-angle-up"></i>');
	        }
	    });			    			
	}

	// Llama el modulo de datos complementarios
	collapsarDatos('grupoGenerales');
	collapsarDatos('grupoComplementarios');
	

	// POPOVER, con información HTML 

	function popoverHtml( btnClass ) {
			
		var grupoClass = '.' + btnClass;		

		    $( grupoClass ).popover({
		        html : true, 
		        // posiciones En caso de necesitar que se actualice el popover (no es preciso)
		        // placement : 'auto', 
				/*placement: function (context, source) {
			        var position = $(source).position();				
			        if (position.left > 515) { return "left";}
			        if (position.left < 515) { return "right";}				
			        if (position.top < 110){ return "bottom";}				
			        return "top";
			    },*/
		        //placement : 'bottom',
		        // añade el titulo desde su html oculto
		        title: function() {
		          return $( grupoClass + '-Title').html();
		        },
		        // añade el contenido desde su html oculto
		        content: function() {
		          return $( grupoClass + '-Content').html();
		        },
		        // colócalo en la ventana, por sobre cualquier objeto
		        container: 'body'
		    });
		    
		    // en caso de que el popover tenga una acción interna, se debe añadir la clase css: extend		    
			$( grupoClass ).click(function (e) {
				e.preventDefault();
			    e.stopPropagation();
			});		    
			
			$(document).click(function (e) {
			    if (($('.popover').has(e.target).length == 0) || $(e.target).is('.close')) {
			        $( grupoClass ).popover('hide');
			    }
			});		    
		    
		    
	}


	// Llama el modulo de datos complementarios
	popoverHtml('aPopoverMenu001');
	popoverHtml('aPopoverUsrOpt');
	popoverHtml('aPopoverInd001');
	//popoverHtml('aPopoverInd002');
    popoverHtml('aPopoverInd003');
	popoverHtml('aPopoverInd004');
    popoverHtml('popservicios1');
    popoverHtml('aPopoverHerramientas001');
    popoverHtml('aPopoverHerramientas002');
    popoverHtml('aPopoverHerramientas003');
    
    popoverHtml('button_popTenenciaCaptacion_depositos001');
	popoverHtml('button_popTenenciaCaptacion_saldo001');
    popoverHtml('button_popTenenciaCaptacion_depositos002');
	popoverHtml('button_popTenenciaCaptacion_saldo002');
    popoverHtml('button_popTenenciaCaptacion_depositos003');
	popoverHtml('button_popTenenciaCaptacion_saldo003');

	

	// MODAL: generar uno con iframe a partir de datos de boton (url)	

	function iframeModal( linkClass ) {
		
		var cssClass = '.' + linkClass;
		var modalId = '#modal-' + linkClass;
		

		$( cssClass ).click(function(){
				
			// Extraigo la url de la imagen que quiero ver
			var src = $(this).attr('data-src');
			// Extraigo el titlulo del link
			var mtitle = $(this).attr('title');
			// En caso de necesitar un modalcon un iframe
			var iframe = '<iframe frameborder="0" scrolling="yes" allowtransparency="true" src=""></iframe>';
			var dynamicModal = $('<div class="modal fade zoom" id="modal-' + linkClass + '"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal"><span>&times;</span></button><h4 class="modal-title"> </h4></div><div class="modal-body">' + iframe + '</div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button><button type="button" class="btn btn-primary">Guardar</button> </div></div></div></div>');

			// le especifico que lo quiero al final del body.
		    $('body').append(dynamicModal);
		    
			// y que busque la etiqueta iframe y genere el documento con sus medidas.
			$( modalId + ' iframe').attr({
				'src' : src,
				// el iframe hereda la medida del .modal-body
				'width' : '100%',
				'height' : '100%'
			});	
			
			// Que genere el titulo 
			$( modalId + ' .modal-title').append(mtitle);	
			
			
			// Personalizo la medidas de las ventanas modal, manejese con precaución.
			 
		    $( modalId ).on('show.bs.modal', function () {

		        $(this).find('.modal-dialog').css({
		                  // modal-dialog abarca el 100% de la ventana.
		                  width:'100%', //ancho de ventana
		                  height:'100%', //alto de ventana
		                  'padding':'0',
						  'margin': '0',
						  'margin-right': 'auto',
						  'margin-left': 'auto'
		           });
		           
		         $(this).find('.modal-content').css({
		                  'border-radius':'0',
		                  'padding':'0'
		          }); 
		           
		         $(this).find('.modal-body').css({
		                  'padding':'0',
		                  // modal body hereda la altura de la ventana
		                  'height': $(window).height() * 0.81
		           });
		    }); 			    

			// Que elimine la ventana después de usar
		  	$( modalId ).on('hidden.bs.modal', function(){
		    	$(this).remove();
			});				
							
		});			
    			
	}

	// Ejecuta el modal de acuerdo a los parametros del link (<a>)
	iframeModal('actualizarDatos');
	iframeModal('capturarBcom');
	iframeModal('miPerfil');
	iframeModal('idHerramienta');
	iframeModal('idPaginaweb');	
	
	


	// MODAL: generar uno con imagen a partir de datos de boton (src)	


	function imageModal( linkimgClass ) {
					
			var cssClass = '.' + linkimgClass;
			var modalId = '#modal-' + linkimgClass;
							 			 
		// Mostrar imagenes de perfil, enlaza la imagen al dat-source del link, asignale la clase de este modulo.			 			 
			$(cssClass).click(function(){
				// agrego el modulo en una variable
				var dynamicModal = $('<div class="modal fade zoom" id="modal-' + linkimgClass + '" tabindex="-1" role="dialog" ><div class="modal-dialog modal-lg"><div class="modal-content"><img /></div><button type="button" class="btn btn-xs btn-danger btn-modal-over" data-dismiss="modal"><span class="glyphicon glyphicon-remove"><!-- icono --></span> Cerrar</button></div></div>');
				// Extraigo la url de la imagen que quiero ver
				var src = $(this).attr('data-src');
				// le especifico que lo quiero al final del body.
			    $('body').append(dynamicModal);
				// Y que busque la etiqueta img y genere la imagen.
				$( modalId + ' img').attr({
					'src' : src,
					'width' : '100%',
					'height' : 'auto'
				});	
				// Borrar ventana
			  	$( modalId ).on('hidden.bs.modal', function(){
			    	$(this).remove();
				});				
				
			});				 
	
	}

	// Ejecuta el modal de acuerdo a los parametros del link (<a>)
	imageModal('idFrente');
	imageModal('idReves');
	imageModal('imgFirma');
	imageModal('imgDictamen');

/**
 * 	Mapa de ubicaaciones de cliente
 *  1- Metodo/Constructor para crear el mapa y personalizarlo
 *  2- Metodo/Constructor de la ventana emergente
 * 
 **/			 

/** 
 * Experimento 4 google map con múltiples markups: 
 * Referencia: 
 * http://stackoverflow.com/questions/17392375/google-maps-api-v3-geocoding-multiple-addresses-and-infowindow
 * Falta ordenar todo este codigo.
 **/
				
	function activa_mapav4(){
					
		    var locations = [
		      ['operacion', 'Blvd. Mario Pani 400, Cuajimalpa de Morelos, Lomas de Santa Fe, 05300 Ciudad de México, D.F.'],
		      ['fiscal', 'Av. Vasco de Quiroga No. 3900, Cuajimalpa, Lomas de Santa Fe, 05300 Ciudad de México, D.F.'],
		      ['particular', 'Av Sta Fe 578, Lomas de Santa Fe, Cuajimalpa de Morelos, 01219 Ciudad de México, D.F.'],
		      ['santander', 'José María Castorena 283, Cuajimalpa, Cuajimalpa de Morelos, 05000 Ciudad de México, D.F.'],
		      ['santander', 'Calz de los Leones 256, Águilas, Álvaro Obregón, 01010 Ciudad de México, D.F.'],
		      ['santander', 'José María Castorena 470, San José de los Cedros, Cuajimalpa de Morelos, 05200 Ciudad de México, D.F.']		     		      
		    ];
		    		
		    var map = new google.maps.Map(document.getElementById('map-canvas'), {
		      zoom: 14,
		      // coordenadas de Mexico DF
		      center: new google.maps.LatLng(19.432608, -99.133208), 
		      mapTypeId: google.maps.MapTypeId.ROADMAP,
		      // deshabilitar interfaz https://developers.google.com/maps/documentation/javascript/controls
		      // habiloitar solo lo necesario: http://www.w3schools.com/googleapi/google_maps_controls.asp
		      disableDefaultUI: true,
				panControl:true,
				zoomControl:true
				//mapTypeControl:true,
				//scaleControl:true,
				//streetViewControl:true,
				//overviewMapControl:true,
				//rotateControl:true								
		    });
		    		
		    var infowindow = new google.maps.InfoWindow();
		    var geocoder = new google.maps.Geocoder();
		    var marker, i;
		
		    for (i = 0; i < locations.length; i++) {
		      geocodeAddress(locations[i]);
		    }
		
		function geocodeAddress(location) {
		  geocoder.geocode( { 'address': location[1]}, function(results, status) {
		  //alert(status);
		    if (status == google.maps.GeocoderStatus.OK) {
		
		      //alert(results[0].geometry.location);
		      map.setCenter(results[0].geometry.location);
		      createMarker(results[0].geometry.location,location[0]+"<br>"+location[1]);
		    }
		    else
		    {
		      alert("Geocode presenta un problema" + status);
		    }
		  }); 
		}


		// Estilos para el mapa (https://developers.google.com/maps/documentation/javascript/styling)
		
		var styles = [
		  {
		    stylers: [
		      { hue: "#ff0000" },
		      { saturation: -20 }
		    ]
		  },{
		    featureType: "road",
		    elementType: "geometry",
		    stylers: [
		      { lightness: 100 },
		      { visibility: "simplified" }
		    ]
		  },{
		    featureType: "road",
		    elementType: "labels",
		    stylers: [
		      { visibility: "off" }
		    ]
		  }
		];
		
		map.setOptions({styles: styles});	


		/** Iconos personalizados de varios tipos: 
		 *  https://developers.google.com/maps/tutorials/customizing/custom-markers 
		 **/

	
		var feature = locations[2][0];
		
		var iconBase = 'http://maps.google.com/mapfiles/kml/pal3/';
		var n=0;
		var icons = {
		  operacion: {
		    icon: iconBase + 'icon21.png'
		  },
		  fiscal: {
		    icon: iconBase + 'icon31.png'
		  },
		  particular: {
		    icon: iconBase + 'icon56.png'
		  },
		  santander: {
		    icon: 'http://maps.google.com/mapfiles/kml/pal2/icon60.png'
		  }		  
		};
		
		function createMarker(latlng,html) {
		  var marker = new google.maps.Marker({
		    position: latlng,
		    icon: icons[locations[n][0]].icon,
		    map: map
		  });
		  		
		  google.maps.event.addListener(marker, 'mouseover', function() { 
		    infowindow.setContent(html);
		    infowindow.open(map, marker);
		  });
				
		  google.maps.event.addListener(marker, 'mouseout', function() { 
		    infowindow.close();
		  });
		  n++;
		}
						
	} // fin de funcion
	
	
	// MODAL: generar uno con mapa de google (url)	
	
 
		function gmapModal( linkmapClass ) {
						
		var cssClass = '.' + linkmapClass;
		var modalId = '#modal-' + linkmapClass;
						 			 
		// Mostrar imagenes de perfil, enlaza la imagen al dat-source del link, asignale la clase de este modulo.			 			 
			$(cssClass).click(function(){
			
			// Extraigo el titlulo del link
			var mtitle = $(this).attr('title');
			
			// agrego el modulo en una variable
			var dynamicModal = $('<div class="modal fade unfold-3d" id="modal-' + linkmapClass + '"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal"><span>&times;</span></button><h4 class="modal-title"></h4></div><div class="modal-body"><div class="row"><div id="map-canvas" style="width:auto;height:400px;"></div></div></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button></div></div></div></div>');
	
			// le especifico que lo quiero al final del body.
		    $('body').append(dynamicModal);
	
			// Que genere el titulo 
			$( modalId + ' .modal-title').append(mtitle);						    
		    
		    					    
			// una vez clickeado y generado el mapa ejecutar función para crear y personalizar el mapa (activa_mapav4)
			$( modalId ).on('shown.bs.modal', function() {
				
				// Invocamos la funcion que genera un mapa de google
				activa_mapav4();
									
			/* Personalizar medidas del modalbox */
		    					 	 		
		        $(this).find('.modal-dialog').css({
		                  width:'90%', //ancho de ventana
		                  height:'auto', 
		                  'padding':'0'
		           });
		           
		         $(this).find('.modal-content').css({
		                  'border-radius':'0',
		                  'padding':'0'
		          }); 
		           
		         $(this).find('.modal-body').css({
		                  width:'auto',
		                  height:'250px', //alto de contenido
		                  'padding':'0'
		           });
		           
		    }); 
	
			// Borrar ventana
		  	$( modalId ).on('hidden.bs.modal', function(){
			    	$(this).remove();
				});				
				
			});				 
	
	}

	// Ejecuta el modal de acuerdo a los parametros del link (<a>)
	gmapModal('mapaGoogle1'); 
 
