var userName;

$(document).ready(function(){
	
	function getParameterByName(name) {
	    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
	    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
	    results = regex.exec(location.search);
	    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
	}
	
	var polizaId = getParameterByName('poliza');
	userName = getParameterByName('user');

	datos = {
		poliza : polizaId
	};

	$.ajax({
				type : "GET",
				url : "https://appsegurosservices-mxsegurosapp-dev.appls.cto2.paas.gsnetcloud.corp/polizaDetalle/service/PolizaDetalleService",
				//url : "http://10.50.90.234:9082/polizaDetalle/service/PolizaDetalleService",
				data : datos,
				dataType : "json",
				error : function(request, status, error) {
					console.log(request.responseText);
					console.log(request.status);
					console.log(request.error);					
				},
				success : function(data) {

					console.log(data);
					var poliza = data.poliza; 
					$("#id-canal").text(poliza.canal);
					$("#id-ramo").text(poliza.ramo);
					$("#id-poliza").text(poliza.poliza);
					$("#id-status").text(poliza.status);
					$("#id-vigencia").text(poliza.vigencia);
					$("#id-inicio").text(poliza.inicio);
					$("#id-fin").text(poliza.fin);
					$("#id-duracion").text(poliza.duracion);
					$("#id-sumaAsegurada").text(poliza.sumaAsegurada);
					$("#id-estatusPago").text(poliza.estatusPago);
					$("#id-primaTotal").text(poliza.primaTotal);
					$("#id-beneficiarioNombre").text(poliza.beneficiarioNombre);
					$("#id-beneficiarioFecha").text(poliza.beneficiarioFecha);
					$("#id-beneficiarioParentesco").text(poliza.beneficiarioParentesco);
				

				}
			});
	
	$("#back_button").click(function(){
		window.location="mis_seguros.html?user=" + userName ;
	});
});
