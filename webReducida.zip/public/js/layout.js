/*
 * Arreglos complementarios.
 * Estos son métodos creados para uso general.
 * Son funciones que solo dependen de bootstrap.min.js
 * 
 * Por ejemplo, para inicializar un tooltip con una clase.
 * Generar un modalbox con una clase que no sea la de bootstrap. 
 * 
 */


/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * 
 *	Navegaciones y sidebars
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


		// Por cada clic a un elemento de menu, agregar la clase 'active' a su contenedor (ul > li)
	
		$('.navbar ul.nav > li > a').on('click',function() {
			$(this).parent('li').addClass( 'active' ).siblings('li').removeClass( 'active' );
		});

		// Sidebar izquierdo mostrar ocultar
		$("#show-sidebar-left").on('click',function(e) {
		        e.preventDefault();
		        $("#wrapper").toggleClass("active-sidebar-left");
		        $('#sidebar-left #navbar .navbar-brand').toggleClass("disabled");
		});	

		// Sidebar izquierdo mostrar ocultar al hover
		/**			$( "#sidebar-left" )
					  .mouseover(function() {
					    $("#wrapper").toggleClass("active-sidebar-left");
					    $('#sidebar-left #navbar a').toggleClass("disabled");
					  })
					  .mouseout(function() {
					    $("#wrapper").toggleClass("active-sidebar-left");
					    $('#sidebar-left #navbar a').toggleClass("disabled");
					  });
		**/					

		// Sidebar derecho mostrar ocultar
		// 11 de enero: cambie la ID por CLASS en el boton, ya que se puede abrir el panel desde algún hotlink
		$(".show-sidebar-right").on('click',function(e) {
		        e.preventDefault();
		        $("#wrapper").toggleClass("active-sidebar-right");
		});		
		
		// **Profundidad en submenus, esto es en caso de requerir ampliar la navegación con más de 2 niveles
		$('ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) {
			event.preventDefault(); 
			event.stopPropagation(); 
			$(this).parent().siblings().removeClass('open');
			$(this).parent().toggleClass('open');
		});
		


/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * 
 *	PopOvers y Tooltips
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

		/** 
		 *  Nuevo popOver: 
		 *  con una clase especifica, tomar contenido oculto de HTML al clic.
		 * 
		 *  TIP: Para limpiar el hashtag de un anchor (#anchor), 
		 * 	se le dice que sustraiga del dato el texto continuo al caracter 0.
		 * 	console.log( $('a.miLinkClase').attr('href').substr(1) );
		 * 
		 **/	

		function richPopoverHTML( claseLink, ruta ) {

				var attrAlt = '';
				var attrHref = '';
				var hrefToid = '';

				// si hay href="#contenido" establecer variable
				if ( $( claseLink ).attr('href') != null ){
					var attrHref = $( claseLink ).attr('href');
					//quitar el hashtag a #contenido para generar un selector en el div embedado de (load).			
					var hrefToid = $( claseLink ).attr('href').substr(1);
				}				
				
				// si hay alt="#descricpion" establecer variable
				if ( $( claseLink ).attr('alt') != null ){
					attrAlt = $( claseLink ).attr('alt');
				}
								
				// si hay ruta creo un div al vuelo para llamar el script, este lo genero en el div: #elementosOcultos al final, antes de los scripts.
				if (ruta != null){
					$( '#elementosOcultos' ).append($( '<div id="'+hrefToid+'">' ).load( ruta ));									
				} else {
				// si no hay ruta solo añade el div con el contenido especificado
					$( '#elementosOcultos' ).append($( '<div id="'+hrefToid+'">' ));									
				}				
				
				// asigno el contenido que se mostrará así como los parametros del popOver
			    $( claseLink ).popover({
			        html : true, 			       		        
			        content: function() {
					        	if ( attrHref || attrAlt ){
					        	// si el contenido tiene HTML y tiene una descripción simple: llamar ambas.
						          return attrAlt + $( attrHref ).html();				          	        		
					          	}			         	
					        },
			        placement : get_popover_placement,	        
			        container: 'body'			        		        
			    });	
			    
			    // Agregar una clase nueva al popover cuando se muestre, para fines de personalización CSS.
			    // http://getbootstrap.com/javascript/#popovers
				$( claseLink ).on('inserted.bs.popover', function () {
					$( '.popover' ).addClass( 'popover-'+hrefToid );
				});  
				
				// evita propagar y se obstruya al clickear en algun otro link
				$( claseLink ).on('click', function (e) {
					e.preventDefault();
				    e.stopPropagation();
				});

				//si hay click fuera del popover: oculta todo
				$(document).on('click', function (e) {
				    if ( ($('.popover').has(e.target).length == 0) || $(e.target).is('.close') ) {
				        $( claseLink ).popover('hide');
				    }
				});					
						 
				
			    // extender la función del popover posicionarlo acorde al display (placement : get_popover_placement)
			    // http://stackoverflow.com/questions/8839387/dynamically-change-the-location-of-the-popover-depending-upon-where-it-displays
			    function get_popover_placement(pop, dom_el) {
			      var width = window.innerWidth;
			      if (width<500) return 'bottom';
			      var left_pos = $(dom_el).offset().left;
			      if (width - left_pos > 400) return 'right';
			      return 'left';
			    }			    	
				

		}


/** 
 * 	Tooltip extendido: con la clase .tooltipHtml, se puede añadir texto con formato HTML en el title 
 *	y se posiciona de acuerdo a la ubicación del elemento que lo ejecuta respecto al display
 * 
 **/

		$(function () {
			$('body').tooltip({
				html: true,
			    selector: '.tooltipHtml',
			    // posición automática de tooltips: https://github.com/twbs/bootstrap/issues/1833
				/**placement:	function (tip, element) {
				        		var offset = $(element).offset();				        		
				        		height = $(document).outerHeight();
				        		width = $(document).outerWidth();
				        		vert = 0.5 * height - offset.top;
				        			vertPlacement = vert > 0 ? 'top' : 'bottom';
				        		horiz = 0.5 * width - offset.left;
				        			horizPlacement = horiz > 0 ? 'left' : 'right';
				        		placement = Math.abs(horiz) > Math.abs(vert) ?  horizPlacement : vertPlacement;
				       		return placement;
						}	**/
				placement: 'bottom'	    
			});			  			  	
		});



/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * 
 *	Modals y ventanas emergentes
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/

		
		
		
		
/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
 * 
 *	Carruseles
 * 
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * **/


		// Carrusel: impedir que avance automáticamente
		
			$('.carousel').carousel({
			    interval: false
			});		
					
					
		// Carrusel de varios thumbs con avance de uno a uno por 3 thumbs

			$('.single-thumb.x2 .item').each(function(){
			  var next = $(this).next();
			  if (!next.length) {
			    next = $(this).siblings(':first');
			  }
			  next.children(':first-child').clone().appendTo($(this));
			  
			  // variante: 1 = 3thumbs, 2 = 4thumbs y así sucesivamente… también se modifica en el css
			  
			  for (var i=0;i>1;i++) { 
			    next=next.next();
			    if (!next.length) {
			    	next = $(this).siblings(':first');
			  	}
			    
			    next.children(':first-child').clone().appendTo($(this));
			  }
			});	
								
					
		// Carrusel de varios thumbs con avance de uno a uno por 3 thumbs

			$('.single-thumb.x3 .item').each(function(){
			  var next = $(this).next();
			  if (!next.length) {
			    next = $(this).siblings(':first');
			  }
			  next.children(':first-child').clone().appendTo($(this));
			  
			  // variante: 1 = 3thumbs, 2 = 4thumbs y así sucesivamente… también se modifica en el css
			  
			  for (var i=0;i<1;i++) { 
			    next=next.next();
			    if (!next.length) {
			    	next = $(this).siblings(':first');
			  	}
			    
			    next.children(':first-child').clone().appendTo($(this));
			  }
			});	
			
		// Carrusel de varios thumbs con avance de uno a uno por 3 thumbs

			$('.single-thumb.x4 .item').each(function(){
			  var next = $(this).next();
			  if (!next.length) {
			    next = $(this).siblings(':first');
			  }
			  next.children(':first-child').clone().appendTo($(this));
			  
			  // variante: 1 = 3thumbs, 2 = 4thumbs y así sucesivamente… también se modifica en el css
			  
			  for (var i=0;i<2;i++) { 
			    next=next.next();
			    if (!next.length) {
			    	next = $(this).siblings(':first');
			  	}
			    
			    next.children(':first-child').clone().appendTo($(this));
			  }
			});					
						

		// Carrusel de varios thumbs con avance de uno a uno por 3 thumbs
			
			$('.single-thumb.x6 .item').each(function(){
			  var next = $(this).next();
			  if (!next.length) {
			    next = $(this).siblings(':first');
			  }
			  next.children(':first-child').clone().appendTo($(this));
			  
			  // variante: 1 = 3thumbs, 2 = 4thumbs y así sucesivamente… también se modifica en el css
			  
			  for (var i=0;i<4;i++) { 
			    next=next.next();
			    if (!next.length) {
			    	next = $(this).siblings(':first');
			  	}
			    
			    next.children(':first-child').clone().appendTo($(this));
			  }
			});		
				
			

			          