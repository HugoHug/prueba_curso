function notyGenerar(type, text) {
	var n = noty({
		text : text,
		type : type,
		dismissQueue : true,
		layout : 'center',
		theme : 'relax'
	});
	console.log('html: ' + n.options.id);
	return n;
}

function validar(e) {
	var vsExprReg = /^([a-z 0-9])+$/i;
	if (!vsExprReg.test(e.key)) {
		var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> Ha introducido caracteres Invalidos</div>');
		setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		return false;
	}
}

$("#buttonLogin").click(function() { 
	var user = $("#usuario").val().trim();
	var password = $("#password").val().trim();
	
	if (user == "" || password == "" || user.length == 0 || password.length == 0) {
		var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> Favor de escribir los Datos</div>');
		setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		return;
	}
	//console.log(user.length);
	if (user.length < 6 || user.length > 17){
		var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i>La longitud del usuario debe de contener entre 6 y 16 caracteres</div>');
		setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		return;
	} 
	
	//console.log(password.length);
	if (password.length < 7 || password.length > 10){
		var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i>La longitud de la contraseña debe de contener entre 7 y 10 caracteres</div>');
		setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		return;
	}
	
	var user_aux= user;
	var pass_aux = password;
	user_aux = user_aux.toUpperCase();
	pass_aux = pass_aux.toUpperCase();
	
	if(user_aux.includes("SANTANDER")  ||  pass_aux.includes("SANTANDER")  ){
		var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> No puedes incluir la palabra Santander</div>');
		setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		return;
	}else if(user_aux.includes("ZUICH") || pass_aux.includes("ZUICH")){
		var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> No puedes incluir la palabra Zuich</div>');
		setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		return;
	} 
	
	var notyProcess = notyGenerar('success','<div class="activity-item"> <i class="glyphicon glyphicon-ok text-success"></i> Procesando...</div>');
	setTimeout(function(){$.noty.close(notyProcess.options.id);},1500);
	
	$('#buttonLogin').attr("disabled", true);
	
	
	datos = {
		user : user,
		password : password
	};
	$.ajax({
		type : "GET",
		url : "https://login-mxsegurosapp-dev.appls.cto2.paas.gsnetcloud.corp/login/service/LoginService",
		//url:"http://10.50.90.234:9080//login/service/LoginService",
		data : datos,
		dataType : "text",
		error : function(request, status, error) {
			console.log(request.responseText);
			console.log(request.status);
			console.log(request.error);
			$('#buttonLogin').attr("disabled", false);
			var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> Error al intentar Iniciar Sesion</div>');
			setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
		},
		success : function(data) {
			console.log(data );
			
			$('#buttonLogin').attr("disabled", false);
			
			if(data == "Error usuario vacio."){
				var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> '+ data + '</div>');
				setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
			}else if(data == "Error contraseña vacia."){
				var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> '+ data + '</div>');
				setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
			}else if(data == "Usuario o contraseña incorrecta!"){
				var notyErrorAjax =notyGenerar('error','<div class="activity-item"> <i class="glyphicon glyphicon-remove text-error"></i> '+ data + '</div>');
				setTimeout(function(){$.noty.close(notyErrorAjax.options.id);},2500);
			}else{
						
			var notySuccess = notyGenerar('success','<div class="activity-item"> <i class="glyphicon glyphicon-ok text-success"></i>Bienvenido ' + data + '</div>');
			setTimeout(function(){$.noty.close(notySuccess.options.id); window.location="html/mis_seguros.html?user=" + user ;},2500);
			}
		}
	});
});