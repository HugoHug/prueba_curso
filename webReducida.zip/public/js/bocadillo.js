
// En un nivel de profundidad se invoca una función;


// popoversimple( 'multicanalPopup' , 'mititlulo' ,  'micontenido' );


		$('.multicanalPopup').on('click',function(){
			
			var laclase = $(this).attr('class');
			
			popoversimple( laclase, 0, 0 );
			
		});
		
		
// generada en otro archivo que está llamado de la raíz


		function popoversimple( clase , titulo , contenido ){
			
			console.log( titulo );
	
			    $('.'+ clase ).popover({
			        html : true, 
			        title: titulo,
			        content: contenido
			    });		
		}

